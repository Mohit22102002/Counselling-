//server.js
//This is the backend side code which takes request from axios.post() from frommntend and stores the data in the mongodb serrver.

const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const cors = require('cors'); // Import cors module
const config = require('./config');
const usersRoutes = require('./routes/users');


const app = express();
const PORT = process.env.PORT || 5000;

app.use(bodyParser.json());

// Enable CORS (Cross-Origin Resource Sharing)
/*With the cors middleware added to your backend, it will include the necessary CORS 
headers in the responses, allowing requests from your frontend running on http://localhost:3000 
to access the resources on your backend server at http://localhost:5000.*/
app.use(cors());

//connectes to mongodb atlas server
//MONGODB_URI is defined in config.js
mongoose.connect(config.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => {
    console.log('Connected to MongoDB Atlas');
})
.catch((err) => {
    console.error('Error connecting to MongoDB Atlas:', err);
    process.exit(1);
});

/*app.use() tells that request made at '/' should be routed to path defined in
/userRoutes, here userRoutes is taken from routes/users.js and the path is directed to 
'/register', so both frontend and backend are executing at '/register' */ 
// Use users routes for /register endpoint
app.use('/', usersRoutes);


app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

