// routes/users.js
const express = require("express");
const router = express.Router();
const User = require("../models/User");
const Excel = require("exceljs");
const Appointment = require("../models/Appointment");
const Updates = require("../models/Updates");
const multer = require('multer'); // Import multer for handling file uploads

// POST create a new user
router.post("/register", async (req, res) => {
  const { name, surname, gender, age, email, phoneNo } = req.body;

  try {
    // Check if the email already exists in the database
    const existingEmail = await User.findOne({ email });
    if (existingEmail) {
      return res.status(400).json({ message: "Email already exists" });
    }

    // Check if the phone number already exists in the database
    const existingPhone = await User.findOne({ phoneNo });
    if (existingPhone) {
      return res.status(400).json({ message: "Phone number already exists" });
    }

    // If email and phone number are unique, create a new user
    const newUser = new User({
      name,
      surname,
      gender, // Add gender to the new user
      age,
      email,
      phoneNo,
      createdAt: new Date(),
    });

    await newUser.save();

    // Create a new update entry
    const newUpdate = new Updates({
      action: "registration", // Add the action field
      message: `${name} ${surname} registered on ${new Date()}`,
      createdAt: new Date(),
    });

    await newUpdate.save();
    res.status(201).json(newUser);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
});


// GET fetch all users
router.get("/users", async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
});

// DELETE delete selected users
router.delete("/users", async (req, res) => {
  const { ids } = req.body;

  try {
    await User.deleteMany({ _id: { $in: ids } });
    res.status(200).json({ message: "Users deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
});

// Export users to Excel
router.post("/export-selected-users", async (req, res) => {
  const { selectedUserIds } = req.body;

  try {
    // Fetch selected users from the database
    const selectedUsers = await User.find({ _id: { $in: selectedUserIds } });

    // Create a new Excel workbook and worksheet
    const workbook = new Excel.Workbook();
    const worksheet = workbook.addWorksheet("Selected Users");

    // Define headers for the Excel file
    worksheet.columns = [
      { header: "Name", key: "name", width: 20 },
      { header: "Surname", key: "surname", width: 20 },
      { header: "Gender", key: "gender", width: 10 }, // Add gender header
      { header: "Age", key: "age", width: 10 },
      { header: "Email", key: "email", width: 30 },
      { header: "Phone Number", key: "phoneNo", width: 15 },
      { header: "Created At", key: "createdAt", width: 20 },
    ];

    // Add selected users data to the worksheet
    selectedUsers.forEach((user) => {
      worksheet.addRow({
        name: user.name,
        surname: user.surname,
        gender: user.gender, // Include gender field
        age: user.age,
        email: user.email,
        phoneNo: user.phoneNo,
        createdAt: user.createdAt.toLocaleString(),
      });
    });

    // Set headers for response
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    res.setHeader(
      "Content-Disposition",
      "attachment; filename=selected_users.xlsx"
    );

    // Write workbook to response
    await workbook.xlsx.write(res);
    res.end();
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
});

// POST book a new appointment
router.post('/book-appointment', async (req, res) => {
  const { name, surname, age, gender, email, phone, subject, date, timeSlot } = req.body;
  const appointmentDate = new Date(date);

  try {
      // Create a new appointment
      const newAppointment = new Appointment({
          name,
          surname,
          age,
          gender,
          email,
          phone,
          subject,
          date: appointmentDate,
          timeSlot,
          year: appointmentDate.getFullYear(),
          month: appointmentDate.getMonth() + 1,
          day: appointmentDate.getDate(),
          createdAt: new Date()
      });

      await newAppointment.save();

      // Create a new update entry
      const newUpdate = new Updates({
          message: `${name} ${surname} booked an appointment for ${subject} on ${date} at ${timeSlot}`,
          action: 'Booked Appointment',
          createdAt: new Date()
      });

      await newUpdate.save();

      res.status(201).json({ message: 'Appointment booked successfully' });
  } catch (err) {
      console.error(err);
      res.status(500).json({ message: 'Server Error' });
  }
});


// GET available time slots for a specific date
router.get("/available-time-slots", async (req, res) => {
  try {
    const { date } = req.query;
    // Find all appointments for the given date
    const appointments = await Appointment.find({ date });
    // Generate an array of time slots from 10 AM to 8 PM
    const availableTimeSlots = generateAvailableTimeSlots();
    // Remove booked time slots from available time slots
    appointments.forEach((appointment) => {
      const index = availableTimeSlots.indexOf(appointment.timeSlot);
      if (index !== -1) {
        availableTimeSlots.splice(index, 1);
      }
    });
    res.json(availableTimeSlots);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
});

// Helper function to generate available time slots from 10 AM to 8 PM
const generateAvailableTimeSlots = () => {
  const timeSlots = [];
  for (let hour = 10; hour <= 20; hour++) {
    timeSlots.push(`${hour}:00 - ${hour + 1}:00`);
  }
  return timeSlots;
};

// GET appointments for a specific month and year
router.get("/appointments", async (req, res) => {
  const { month, year } = req.query;

  try {
    // Fetch appointments for the specified month and year
    const appointments = await Appointment.find({
      month: parseInt(month),
      year: parseInt(year),
    }).sort({ date: 1, time: 1 }); // Sort appointments by date and time

    res.json(appointments);
  } catch (err) {
    console.error("Error fetching appointments:", err);
    res.status(500).json({ message: "Server Error" });
  }
});

// GET fetch all updates
router.get('/updates', async (req, res) => {
  try {
      const updates = await Updates.find().sort({ createdAt: -1 }); // Sort by createdAt in descending order
      res.json(updates);
  } catch (err) {
      console.error('Error fetching updates:', err);
      res.status(500).json({ message: 'Server Error' });
  }
});

module.exports = router;

