// models/Appointment.js
const mongoose = require('mongoose');

const appointmentSchema = new mongoose.Schema({
    name: String,
    surname: String,
    age: Number,
    gender: String,
    email: String,
    phone: String,
    subject: String,
    date: Date,
    timeSlot: String,
    year: Number, // Add year field
    month: Number, // Add month field
    day: Number, // Add day field
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Appointment', appointmentSchema);
