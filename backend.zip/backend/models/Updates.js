// models/Updates.js
const mongoose = require('mongoose');

const updatesSchema = new mongoose.Schema({
    message: {
        type: String,
        required: true
    },
    action: {
        type: String,
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Updates', updatesSchema);
