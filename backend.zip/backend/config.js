// config.js
module.exports = {
    MONGODB_URI: "mongodb+srv://mohitmalghade44:2BK2fIqv4i9CWHRl@cluster0.aaqatg7.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
};
//here database name can also be specifies but i haven't so it creates a default database with name 'test'